## How to use

1. Download [here](https://github.com/yuu-s23/raspberry-pi-setup/archive/master.zip)

1. Open zip file

1. Use `ssh` and `wpa_supplicant.conf` file

## License
BSD Zero Clause License